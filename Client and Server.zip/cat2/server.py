import flwr as fl

# Define strategy (optional, can customize aggregation)
strategy = fl.server.strategy.FedAvg()

# Start server
fl.server.start_server(
    server_address="0.0.0.0:8080",  # Listen on all network interfaces
    config=fl.server.ServerConfig(num_rounds=3),  # number of FL rounds
    strategy=strategy
)
